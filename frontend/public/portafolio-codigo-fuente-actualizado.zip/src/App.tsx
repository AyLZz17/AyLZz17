import { useRef, useState, type ChangeEvent, type ReactNode } from 'react'

const profileLinks = {
  github: 'https://github.com/',
  email: 'mailto:hola@desarrollador.dev',
  whatsapp: 'https://wa.me/',
}

const projects = [
  {
    number: '01',
    title: 'Sistema de gestión',
    type: 'Full-stack · 2025',
    description:
      'Plataforma modular para administrar clientes, operaciones y métricas en tiempo real desde una interfaz rápida y clara.',
    stack: ['React', 'TypeScript', 'Node.js'],
  },
  {
    number: '02',
    title: 'Experiencia e-commerce',
    type: 'Frontend · 2024',
    description:
      'Tienda digital enfocada en rendimiento, descubrimiento de producto y un proceso de compra sin fricciones.',
    stack: ['Next.js', 'Tailwind', 'Stripe'],
  },
  {
    number: '03',
    title: 'Dashboard analítico',
    type: 'Producto · 2024',
    description:
      'Visualización de datos complejos convertidos en indicadores accionables para equipos de producto y negocio.',
    stack: ['React', 'D3.js', 'PostgreSQL'],
  },
]

const repositories = [
  { name: 'design-system', description: 'Componentes accesibles y reutilizables para productos digitales.', language: 'TypeScript', stars: 128 },
  { name: 'api-starter', description: 'Punto de partida seguro y escalable para APIs modernas.', language: 'Node.js', stars: 84 },
  { name: 'portfolio-v2', description: 'Código fuente y experimentos visuales de este portafolio.', language: 'React', stars: 56 },
]

function Icon({ name, className = 'size-5' }: { name: 'arrow' | 'github' | 'mail' | 'whatsapp' | 'upload' | 'code' | 'star'; className?: string }) {
  const paths: Record<string, ReactNode> = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    github: <path d="M15 22v-4c.14-1.25-.3-2.2-1-2.75 3.3-.36 6.75-1.62 6.75-7.35A5.75 5.75 0 0 0 19.22 4a5.3 5.3 0 0 0-.15-3.8S17.88-.18 15 2.57a13.16 13.16 0 0 0-6.3 0C5.78-.18 4.58.2 4.58.2A5.3 5.3 0 0 0 4.43 4 5.75 5.75 0 0 0 2.9 7.9c0 5.72 3.48 6.98 6.78 7.35A3.4 3.4 0 0 0 8.7 18v4" />,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m4 7 8 6 8-6" /></>,
    whatsapp: <><path d="M20 11.6a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.6Z" /><path d="M8.5 7c.4 4.8 3.2 7.6 8 8" /></>,
    upload: <><path d="M12 16V4m-4 4 4-4 4 4" /><path d="M5 15v4h14v-4" /></>,
    code: <><path d="m9 18-6-6 6-6m6 0 6 6-6 6" /></>,
    star: <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z" />,
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function ContactLink({ href, label, icon }: { href: string; label: string; icon: 'github' | 'mail' | 'whatsapp' }) {
  return (
    <a className="glass group flex items-center gap-3 rounded-full px-4 py-2.5 text-sm text-white/70 transition hover:border-red-400/40 hover:bg-red-500/10 hover:text-white" href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer">
      <Icon name={icon} className="size-4 text-red-400" />
      {label}
    </a>
  )
}

export default function App() {
  const [photo, setPhoto] = useState<string>()
  const [openProject, setOpenProject] = useState(0)
  const fileInput = useRef<HTMLInputElement>(null)

  function handlePhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    setPhoto(URL.createObjectURL(file))
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#10090b] text-white">
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_15%_15%,rgba(220,38,38,0.18),transparent_28%),radial-gradient(circle_at_85%_55%,rgba(127,29,29,0.2),transparent_30%)]" />
      <div className="noise pointer-events-none fixed inset-0 opacity-20" />

      <nav className="relative mx-auto flex max-w-7xl items-center justify-between px-6 py-6 lg:px-12">
        <a href="#inicio" className="flex items-center gap-3 font-semibold tracking-tight">
          <span className="flex size-9 items-center justify-center rounded-full bg-red-500 font-mono text-xs">DS</span>
          <span className="hidden sm:block">desarrollador.software</span>
        </a>
        <div className="glass flex items-center gap-1 rounded-full p-1 text-xs text-white/60 sm:text-sm">
          <a className="rounded-full px-3 py-2 transition hover:bg-white/10 hover:text-white" href="#perfil">Perfil</a>
          <a className="rounded-full px-3 py-2 transition hover:bg-white/10 hover:text-white" href="#proyectos">Proyectos</a>
          <a className="rounded-full px-3 py-2 transition hover:bg-white/10 hover:text-white" href="#repositorios">Repos</a>
        </div>
      </nav>

      <div className="relative mx-auto max-w-7xl space-y-16 px-4 pb-10 pt-8 sm:space-y-20 sm:px-6 sm:pb-14 sm:pt-12 lg:space-y-28 lg:px-12 lg:pb-16 lg:pt-16">
        <section id="inicio" className="grid min-h-[65vh] content-center gap-12 lg:grid-cols-[1.3fr_.7fr] lg:items-center">
          <div>
            <p className="mb-5 font-mono text-xs uppercase tracking-[.28em] text-red-400">Full-stack developer · Portfolio</p>
            <h1 className="text-[clamp(3.4rem,8vw,7.7rem)] font-semibold leading-[.87] tracking-[-.065em]">
              Código con
              <span className="block text-white/30">propósito.</span>
            </h1>
            <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/55">Transformo ideas complejas en productos digitales simples, rápidos y memorables.</p>
          </div>
          <div className="glass relative rounded-[2rem] p-7">
            <div className="absolute -right-3 -top-3 size-24 rounded-full bg-red-500/20 blur-2xl" />
            <p className="font-mono text-[.65rem] uppercase tracking-[.2em] text-white/35">Disponible para</p>
            <p className="mt-3 text-2xl font-medium">Nuevos proyectos y colaboraciones.</p>
            <div className="mt-7 flex flex-wrap gap-2">
              <ContactLink href={profileLinks.github} label="GitHub" icon="github" />
              <ContactLink href={profileLinks.email} label="Correo" icon="mail" />
              <ContactLink href={profileLinks.whatsapp} label="WhatsApp" icon="whatsapp" />
            </div>
          </div>
        </section>

        <section id="perfil" className="scroll-mt-24">
          <SectionTitle number="01" title="Perfil" subtitle="Sobre mí" />
          <div className="grid gap-6 lg:grid-cols-[.72fr_1.28fr]">
            <div className="glass group relative min-h-96 overflow-hidden rounded-[2rem]">
              {photo ? <img src={photo} alt="Foto de perfil" className="absolute inset-0 size-full object-cover" /> : <div className="absolute inset-0 flex flex-col items-center justify-center text-white/30"><div className="mb-4 flex size-20 items-center justify-center rounded-full border border-dashed border-white/20"><Icon name="upload" /></div><span className="text-sm">Añade tu foto</span></div>}
              <div className="absolute inset-x-4 bottom-4">
                <input ref={fileInput} className="hidden" type="file" accept="image/*" onChange={handlePhoto} />
                <button onClick={() => fileInput.current?.click()} className="glass flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 text-sm transition hover:bg-red-500/20"><Icon name="upload" className="size-4" /> {photo ? 'Cambiar fotografía' : 'Subir fotografía'}</button>
              </div>
            </div>
            <div className="glass flex flex-col justify-between rounded-[2rem] p-7 sm:p-10">
              <div>
                <p className="text-2xl font-medium leading-snug sm:text-4xl">Desarrollador enfocado en construir productos que se sienten tan bien como funcionan.</p>
                <p className="mt-6 max-w-2xl leading-relaxed text-white/50">Combino pensamiento de producto, diseño de interfaces e ingeniería para llevar proyectos desde la primera idea hasta producción. Me importan el detalle, el rendimiento y el código que otros puedan mantener.</p>
              </div>
              <div className="mt-12 grid grid-cols-3 gap-3 border-t border-white/10 pt-7">
                {[['4+', 'Años'], ['24', 'Proyectos'], ['100%', 'Compromiso']].map(([value, label]) => <div key={label}><strong className="block text-2xl text-red-400 sm:text-3xl">{value}</strong><span className="mt-1 block text-xs text-white/35">{label}</span></div>)}
              </div>
            </div>
          </div>
        </section>

        <section id="proyectos" className="scroll-mt-24">
          <SectionTitle number="02" title="Proyectos" subtitle="Trabajo seleccionado" />
          <div className="glass overflow-hidden rounded-[2rem] px-6 sm:px-9">
            {projects.map((project, index) => (
              <article key={project.title} className="border-b border-white/10 last:border-0">
                <button className="group flex w-full items-center gap-4 py-7 text-left" onClick={() => setOpenProject(openProject === index ? -1 : index)} aria-expanded={openProject === index}>
                  <span className="font-mono text-xs text-red-400">{project.number}</span>
                  <span className="flex-1 text-xl font-medium sm:text-3xl">{project.title}</span>
                  <span className="hidden text-sm text-white/35 sm:block">{project.type}</span>
                  <span className={`flex size-10 items-center justify-center rounded-full border border-white/10 transition ${openProject === index ? 'rotate-90 bg-red-500 text-white' : 'group-hover:border-red-400/50'}`}><Icon name="arrow" /></span>
                </button>
                <div className={`grid transition-all duration-300 ${openProject === index ? 'grid-rows-[1fr] pb-7' : 'grid-rows-[0fr]'}`}>
                  <div className="overflow-hidden"><div className="grid gap-5 pl-8 sm:grid-cols-[1fr_auto] sm:pl-10"><p className="max-w-2xl leading-relaxed text-white/50">{project.description}</p><div className="flex flex-wrap gap-2">{project.stack.map(item => <span key={item} className="rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 font-mono text-xs text-red-300">{item}</span>)}</div></div></div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="repositorios" className="scroll-mt-24">
          <SectionTitle number="03" title="Repositorios" subtitle="Open source en GitHub" />
          <div className="grid gap-4 md:grid-cols-3">
            {repositories.map(repo => (
              <a key={repo.name} href={`${profileLinks.github}${repo.name}`} target="_blank" rel="noreferrer" className="glass group flex min-h-64 flex-col rounded-[2rem] p-7 transition hover:-translate-y-1 hover:border-red-400/40 hover:bg-red-500/10">
                <div className="flex items-center justify-between"><span className="flex size-11 items-center justify-center rounded-full bg-red-500/15 text-red-400"><Icon name="code" /></span><Icon name="arrow" className="size-5 text-white/25 transition group-hover:translate-x-1 group-hover:text-red-400" /></div>
                <div className="mt-auto"><h3 className="text-xl font-medium">{repo.name}</h3><p className="mt-2 text-sm leading-relaxed text-white/45">{repo.description}</p><div className="mt-5 flex items-center justify-between font-mono text-xs text-white/35"><span><i className="mr-2 inline-block size-2 rounded-full bg-red-400" />{repo.language}</span><span className="flex items-center gap-1"><Icon name="star" className="size-3" />{repo.stars}</span></div></div>
              </a>
            ))}
          </div>
        </section>

        <footer className="flex flex-col gap-4 border-t border-white/10 py-7 text-xs text-white/30 sm:flex-row sm:items-center sm:justify-between">
          <span>© 2025 · Desarrollador Software</span>
          <span>Diseño, código y detalle.</span>
        </footer>
      </div>
    </main>
  )
}

function SectionTitle({ number, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return <div className="mb-8 flex items-end justify-between"><div><p className="mb-2 font-mono text-xs tracking-[.2em] text-red-400">{number} / {subtitle}</p><h2 className="text-4xl font-semibold tracking-tight sm:text-6xl">{title}</h2></div><span className="hidden h-px w-1/3 bg-gradient-to-r from-red-500/50 to-transparent sm:block" /></div>
}
